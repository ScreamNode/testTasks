/**
 * Created by ASysoev on 21.08.2016.
 */
angular.module('AxxonCameras').controller('watchCtrl', ['Cameras', '$scope', function (Cameras, $scope) {

    //get sources of video streams
    Cameras.getAllSources().success(function (response) {
        $scope.sources = response;
    });

    //define default stream channel
    $scope.stream = Cameras.getVideoStream($scope.camera, 'mjpeg', 960, 480, 0000000000001);

    //set the stream properties
    $scope.setCamera = function (name) {
        $scope.camera = name;
        $scope.stream = Cameras.getVideoStream($scope.camera, 'mjpeg', 960, 480, 0000000000001);
    };

    //get source images
    $scope.snapshot = function (server, width, height, unixTime) {
        return Cameras.getSnapshot(server, width, height, unixTime);
    };

    //set data and time and load stream from archive
    $scope.getArchiveStream = function () {
        Cameras.getUuid().success(function (response) {
            $scope.timePick = $('#_time-picker').val().replace(/-/g, '').replace(/:/g, '').replace(/ /, 'T');
            $scope.uuid = response;
            $scope.stream = '/asip-api/archive/media/' + $scope.camera + '/' + $scope.timePick + '.000?_=1471893062008&amp;format=mjpeg&amp;w=960&amp;h=&amp;speed=1&amp;id=' + $scope.uuid
        });
    };

}]);