/**
 * Created by ASysoev on 21.08.2016.
 */
angular.module('AxxonCameras').factory('Cameras', function CamerasFactory($http) {
    return {
        getAllSources: function () {
            return $http({
                method: 'GET',
                url: '/asip-api/video-origins/'
            })
        },
        getUuid: function () {
            return $http({
                method: 'GET',
                url: '/asip-api/uuid/'
            })
        },
        getVideoStream: function (server, videoFormat, width, height, unixTime) {
            return '/asip-api/live/media/' + server + '?format=' + videoFormat + '&amp;w=' + width + '&amp;h=' + height + '&amp;_=' + unixTime

        },
        getSnapshot: function (server, width, height, unixTime) {
            return '/asip-api/live/media/snapshot/' + server + '?w=' + width + '&amp;h=' + height + '&amp;_=' + unixTime;
        }

    }
});