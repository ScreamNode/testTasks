/**
 * Created by ASysoev on 22.08.2016.
 */
angular.module('AxxonCameras').directive('timePicker', function() {
    return {
        restrict: 'E',
        templateUrl: 'templates/timepicker.html',
        link: function() {
            //    launch timepicker
            $('#_time-picker').datetimepicker({
                dateFormat: 'yy-mm-dd',
                timeFormat: 'HH:mm:ss',
                stepHour: 2,
                stepMinute: 10,
                stepSecond: 10
            });
        }
    };
});